/**
 * Blitz.js
 *
 * @description :: Blitz table with fields
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
    options: {
        tableName: 'hr_candidate',
        classMethods: {},
        instanceMethods: {},
        hooks: {}

    },
    attributes: {
        candidateId: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: Sequelize.STRING(50),
        },
        Totalexp: {
            type: Sequelize.INTEGER,
        },
        Relexp: {
            type: Sequelize.INTEGER,
        },
        RecruiterName: {
            type: Sequelize.STRING,
        },
        InterviewerName: {
            type: Sequelize.STRING,
        },
        Feedback: {
            type: Sequelize.STRING,
        },
        Selected: {
            type: Sequelize.STRING,
        },
        createdAt: {
            type: Sequelize.DATE,
            field: 'createdAt'
        },
        updatedAt: {
            type: Sequelize.DATE,
            field: 'updatedAt'
        }
    },
};

function seed(name, next) {
    if (sails.config.models.seed) {
        const data = require('../../data/activity');

        _.forEach(data, function(row) {
            Activity.create(row);
        });

        next();
    } else {
        return next()
    }
}
