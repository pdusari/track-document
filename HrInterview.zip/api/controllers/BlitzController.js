/**
 * BlitzController
 *
 * @description :: Server-side logic for managing Blitzs
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

